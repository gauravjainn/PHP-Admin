<?php

namespace App\Controllers\Admin;
use App\Controllers\BaseController;
use App\Models\UserModel;

class AdminController extends BaseController
{
    // this method is use to show login page
    public function login()
    {
         return view('admin/auth/login');
    }

    // this method is use to check for authentication
    public function auth()
    {

        $input = $this->validate([
            'email' => 'required|valid_email',
            'password' => 'required'
        ]);

        if (!$input) {
            return view('admin/auth/login',[
                'validation' => $this->validator,
            ]);
        }
        else
        {
            $email = $this->request->getVar('email');
            $password = $this->request->getVar('password');

            $model = new UserModel;
            $user = $model->where('email',$email)->first();

            if(isset($user) && !empty($user))
            {
                if(md5($password) == $user['password'])
                {
                    // Stroing session values
                    $this->setUserSession($user);
                    // Redirecting to dashboard after login
                    return redirect()->to(base_url('admin/dashboard'));
                }
                else
                {
                    return redirect()->route('login')->with('message','please enter correct password');
                }
            }
            else
            {
                return redirect()->route('login')->with('message','please enter valid email address and password.');
            }
        }
    }

    // setting session for logged in user
    private function setUserSession($user)
    {
        $data = [
            'id' => $user['id'],
            'name' => $user['name'],
            'email' => $user['email'],
            'role_id' => $user['role_id'],
            'isLoggedIn' => true
        ];

        session()->set($data);
        return true;
    }

    // this method is use to show dashboard page
    public function dashboard()
    {
        $model = new UserModel;
        $user_get = $model->where('role_id !=',1)->findAll();
    
        // taking out user count
        $user_count = count($user_get);
        return view('admin/admin_dashboard/dashboard',['count'=>$user_count]);
    }

    // this method is to logout the admin
    public function logout()
    {
        session()->destroy();
        return redirect()->route('login');
    }

}
