<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\CheckIn;
use App\Models\Leaves;

// Import Excel Package
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Writer\Xlsx;

class AttendanceController extends BaseController
{
    // this method is to show the checkin list of users
    public function index()
    {
       return view('admin/admin_attendance/index');
    }

    // this method is use to load the user checkin data
    public function loadCheckin()
    {
        // echo "<pre>";
        // print_r($this->request->getVar("emp_code"));
        // die;

        $from_date = $this->request->getVar('from_date');
        $to_date = $this->request->getVar('To_date');
        $employee_code = $this->request->getVar('emp_code');

    //    $get_date = $this->request->getVar('date_pick');
        $params['draw'] = $_REQUEST['draw'];
        $start = $_REQUEST['start'];
        $length = $_REQUEST['length'];

        /* If we pass any extra data in request from ajax */
        //$value1 = isset($_REQUEST['key1'])?$_REQUEST['key1']:"";

        /* If we pass any extra data in request from ajax */
        // $value1 = isset($get_date)? $get_date:"";

        $value1 =  isset($from_date)? $from_date:"";
        $value2 =  isset($to_date) ? $to_date:"";
        $value3 = isset($employee_code) ? $employee_code:"";

        /* Value we will get from typing in search */
        // $search_value = $_REQUEST['search']['value'];
        
        // $model = new CheckIn;
        $db      = \Config\Database::connect();
        $data = [];

        $fetch = $db->table("checkins"); 
        $fetch->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        $fetch->join('users', 'users.id = checkins.user_id');

        if(isset($value3) && !empty($value3))
        {
            $fetch->where('users.employee_code',$value3);
        }

        if(isset($value1) && !empty($value1) && isset($value2) && !empty($value2))
        {
            $fetch->where('checkins.date >=',$value1);
            $fetch->where('checkins.date <=',$value2);
        }
        elseif($value1!="" || $value2!="")
        {
            if($value1!="")
            {
                $fetch->where('checkins.date',$value1);
            }
            else
            {
                $fetch->where('checkins.date',$value2);
            }

        }
        else
        {
            $current_date = date('Y-m-d');
            $fetch->where('date',$current_date);
        }
       
        $result = $fetch->orderBy('checkins.id','DESC')->limit($length,$start)->get()->getResultArray();
        $counting = count($result);

        // if(!empty($search_value) || !empty($value1) || !empty($value2)){

        //     if($value1!="" && $value2!="")
        //     {
        //         $fetch = $db->table("checkins");
        //         $fetch->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $fetch->join('users', 'users.id = checkins.user_id');
        //         $fetch->where('checkins.date >=',$value1);
        //         $fetch->where('checkins.date <=',$value2);
        //         $result_count = $fetch->get()->getResult();
        //         $counting = count($result_count);
    
        //         $builder = $db->table('checkins');
        //         $builder->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $builder->join('users', 'users.id = checkins.user_id');
        //         $builder->where('checkins.date >=',$value1);
        //         $builder->where('checkins.date <=',$value2);
        //         $result = $builder->orderBy('checkins.id','DESC')->limit($length,$start)->get()->getResultArray();
        //     }
        //     elseif($value1!="" || $value2!="")
        //     {
               
        //         $fetch = $db->table("checkins");
        //         $fetch->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $fetch->join('users', 'users.id = checkins.user_id');
        //         if($value1!="")
        //         {
        //             $fetch->where('checkins.date',$value1);
        //         }
        //         else
        //         {
        //             $fetch->where('checkins.date',$value2);
        //         }
                
        //         $result_count = $fetch->get()->getResult();
        //         $counting = count($result_count);
    
        //         $builder = $db->table('checkins');
        //         $builder->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $builder->join('users', 'users.id = checkins.user_id');
        //         if($value1!="")
        //         {
        //             $builder->where('checkins.date',$value1);
        //         }
        //         else
        //         {
        //             $builder->where('checkins.date',$value2);
        //         }
        //         $result = $builder->orderBy('checkins.id','DESC')->limit($length,$start)->get()->getResultArray();
        //     }
        //     else
        //     {
        //         $current_date = date('Y-m-d');
        //         $fetch = $db->table("checkins");
        //         $fetch->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $fetch->join('users', 'users.id = checkins.user_id');
        //         $fetch->like('users.name',$search_value);
        //         $fetch->orLike('users.employee_code',$search_value);
        //         $fetch->where('date',$current_date);
        //         $result_count = $fetch->get()->getResult();
    
        //         $counting = count($result_count);
    
        //         $builder = $db->table('checkins');
        //         $builder->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //         $builder->join('users', 'users.id = checkins.user_id');
        //         $builder->like('users.name',$search_value);
        //         $builder->orLike('users.employee_code',$search_value);
        //         $builder->where('date',$current_date);
        //         $result = $builder->orderBy('checkins.id','DESC')->limit($length,$start)->get()->getResultArray();
        //     }
        // }else{


        //     $current_date = date('Y-m-d');
            
        //     // count all data
        //     $total_count =  $model->where('date',$current_date)->findAll();
        //     $counting = count($total_count);

        //     $builder = $db->table('checkins');
        //     $builder->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        //     $builder->join('users', 'users.id = checkins.user_id');
        //     $builder->where('date',$current_date);
        //     $result = $builder->orderBy('checkins.id','DESC')->limit($length,$start)->get()->getResultArray();
        // }

    // echo "<pre>";
    // print_r($result);
    // die;

        $no = 0;
        foreach ( $result as $customers) {
           $no++;
           $row = array();
           $row['id'] = $no;
           $row['employee_code'] = $customers['emp_code'];
           $row['name'] = $customers['name'];
           $checkin_status = $customers['checkstatus'];
           if($checkin_status == 1)
           {
              $row['status'] = "CheckIn";
           }
           $row['date'] = date('d-m-Y h:i:s', strtotime($customers['date']));
           $row['action'] = checkin_view();
           $data[] = $row;
       }
        
        $json_data = array(
            "draw" => intval($params['draw']),
            "recordsTotal" => $counting,
            "recordsFiltered" => $counting,
            "data" => $data   // total data array
        );

        echo json_encode($json_data);

    }

    // this method is use to show the list of leaves user
    public function userLeaves()
    {
        return view('admin/admin_attendance/leaves');
    }

    // this method is use to load the user leaves data
    public function loadLeaves()
    {
        $get_date = $this->request->getVar('date_pick');
        $params['draw'] = $_REQUEST['draw'];
        $start = $_REQUEST['start'];
        $length = $_REQUEST['length'];

        /* If we pass any extra data in request from ajax */
        $value1 = isset($get_date)? $get_date:"";

        /* Value we will get from typing in search */
        $search_value = $_REQUEST['search']['value'];
        
        $model = new Leaves;
        $db      = \Config\Database::connect();
        $data = [];

        if(!empty($search_value)|| !empty($value1)){

            if($value1!="")
            {
              
                $fetch = $db->table("leaves");
                $fetch->select('users.employee_code as emp_code,users.name,leaves.status as checkstatus,leaves.created_at as date');
                $fetch->join('users', 'users.id = leaves.user_id');
                $fetch->like('leaves.date',$value1);
        
                $result_count = $fetch->get()->getResult();

                $counting = count($result_count);

                $builder = $db->table('leaves');
                $builder->select('users.employee_code as emp_code,users.name,leaves.status as checkstatus,leaves.created_at as date');
                $builder->join('users', 'users.id = leaves.user_id');
                $builder->like('leaves.date',$value1);
                $result = $builder->orderBy('leaves.id','DESC')->limit($length,$start)->get()->getResultArray();


            }
            else
            {
                
                $fetch = $db->table("leaves");
                $fetch->select('users.employee_code as emp_code,users.name,leaves.status as checkstatus,leaves.created_at as date');
                $fetch->join('users', 'users.id = leaves.user_id');
                $fetch->like('users.name',$search_value);
                $fetch->orLike('users.employee_code',$search_value);
                $result_count = $fetch->get()->getResult();

                $counting = count($result_count);

                $builder = $db->table('leaves');
                $builder->select('users.employee_code as emp_code,users.name,leaves.status as checkstatus,leaves.created_at as date');
                $builder->join('users', 'users.id = leaves.user_id');
                $builder->like('users.name',$search_value);
                $builder->orLike('users.employee_code',$search_value);
                $result = $builder->orderBy('leaves.id','DESC')->limit($length,$start)->get()->getResultArray();

            }

        }else{
            // count all data
            $total_count =  $model->findAll();

            $counting = count($total_count);

            $builder = $db->table('leaves');
            $builder->select('users.employee_code as emp_code,users.name,leaves.status as checkstatus,leaves.created_at as date');
            $builder->join('users', 'users.id = leaves.user_id');
            $result = $builder->orderBy('leaves.id','DESC')->limit($length,$start)->get()->getResultArray();
        }

        $no = 0;
        foreach ( $result as $customers) {
           $no++;
           $row = array();
           $row['id'] = $no;
           $row['employee_code'] = $customers['emp_code'];
           $row['name'] = $customers['name'];
           $checkin_status = $customers['checkstatus'];
           if($checkin_status == 1)
           {
              $row['status'] = "Leave";
           }
           $row['date'] = date('d-m-Y h:i:s', strtotime($customers['date']));
           $row['action'] = checkin_view();
           $data[] = $row;
       }
        
        $json_data = array(
            "draw" => intval($params['draw']),
            "recordsTotal" => $counting,
            "recordsFiltered" => $counting,
            "data" => $data   // total data array
        );

        echo json_encode($json_data);
    }

    // this method is use to export the data
    public function exportData()
    {
       $export_date = $this->request->getVar('btn');
       $from_date = $this->request->getVar('from_date');
       $to_date =  $this->request->getVar('to_date');
       $emp_code = $this->request->getVar('emp_code');

       $from_date =  isset($from_date)? $from_date:"";
       $to_date =  isset($to_date) ? $to_date:"";
       $emp_code = isset($emp_code) ?  $emp_code:"";

        $db      = \Config\Database::connect();

        $fetch = $db->table("checkins"); 
        $fetch->select('users.employee_code as emp_code,users.name,checkins.status as checkstatus,checkins.created_at as date');
        $fetch->join('users', 'users.id = checkins.user_id');

        if(isset($emp_code) && !empty($emp_code))
        {
            $fetch->where('users.employee_code',$emp_code);
        }

        if(isset($from_date) && !empty($from_date) && isset($to_date) && !empty($to_date))
        {
            $fetch->where('checkins.date >=',$from_date);
            $fetch->where('checkins.date <=',$to_date);
        }
        elseif($from_date!="" || $to_date!="")
        {
            if($from_date!="")
            {
                $fetch->where('checkins.date',$from_date);
            }
            else
            {
                $fetch->where('checkins.date',$to_date);
            }

        }
        else
        {
            $current_date = date('Y-m-d');
            $fetch->where('date',$current_date);
        }
       
        $result = $fetch->orderBy('checkins.id','DESC')->get()->getResultArray();

       if($export_date == "excel")
       {

        $fileName = 'checkin.xlsx'; // File is to create

        $spreadsheet = new Spreadsheet();

        $sheet = $spreadsheet->getActiveSheet();
		$sheet->setCellValue('A1', 'Id');
		$sheet->setCellValue('B1', 'Employee Code');
		$sheet->setCellValue('C1', 'Name');
		$sheet->setCellValue('D1', 'status');
		$sheet->setCellValue('E1', 'date/time');

        $rows = 2;

        $n =0;
        foreach ( $result as $val) {
            $n++;
			$sheet->setCellValue('A' . $rows, $n);
			$sheet->setCellValue('B' . $rows, $val['emp_code']);
			$sheet->setCellValue('C' . $rows, $val['name']);
            if($val['checkstatus'] == 1)
            {
            $sheet->setCellValue('D' . $rows, 'checkin');
            }
			
			$sheet->setCellValue('E' . $rows, date('d-m-Y h:i:s', strtotime($val['date'])));

            $rows++;
		}

        $writer = new Xlsx($spreadsheet);

		// file inside /public folder
		$filepath = $fileName;

		$writer->save($filepath);

		header("Content-Type: application/vnd.ms-excel");
		header('Content-Disposition: attachment; filename="' . basename($filepath) . '"');

		header('Expires: 0');
		header('Cache-Control: must-revalidate');
		header('Pragma: public');
		header('Content-Length: ' . filesize($filepath));
		flush(); // Flush system output buffer
		readfile($filepath);

		exit;
       }
       else
       {
            $dompdf = new \Dompdf\Dompdf();
            $dompdf->loadHtml(view('admin/admin_attendance/checkin-pdf', ["result" => $result]));

       }
    }

}
