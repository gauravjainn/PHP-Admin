<footer class="main-footer">
<strong>Copyright &copy; 2022 .</strong>

<div class="float-right d-none d-sm-inline-block">
All rights reserved.
</div>
</footer>