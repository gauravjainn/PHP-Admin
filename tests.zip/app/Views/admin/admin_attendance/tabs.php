<div class="panel-footer row "><!-- panel-footer -->
    <div class="col-md-6 ">
         <div class="previous d-flex align-items-baseline">
                <a href="<?=  base_url('admin/user-checkin') ?>" class="btn  btn-lg btn-block <?= (current_url() == base_url('admin/user-checkin'))  ?   'btn-primary' : 'btn-secondary' ?>">Checkin</a>
                <a href="<?= base_url('admin/user-leaves')  ?>" type="button" class="btn btn-lg btn-block <?= (current_url() == base_url('admin/user-leaves'))  ?   'btn-primary' : 'btn-secondary' ?>" style="margin-left: 5px;">Leaves</a>    
    </div>
   
</div>

<div class="col-md-6">

<div class="date-pick d-flex justify-content-end" style="margin-left: 8px;">
                <!-- <input type="submit" id="filter" class="btn-inline btn btn-danger ml-2" value="Filter" name="search" > -->

                <a href="javascript:void(0);" id="calendar-btn"><i class="fa fa-calendar mt-4 text-success" aria-hidden="true"></i></a>
                    <!-- <input type="hidden" id="test" data-block=""  value="">
                    <input type="date" name="date" value="" class="form-control" id="def_value" > -->
    </div>

</div>



</div>




