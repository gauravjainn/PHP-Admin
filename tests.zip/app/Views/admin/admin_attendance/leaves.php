<?=  $this->extend('admin/admin_layouts/dashboard_layout'); ?>

<?=  $this->section('content-header') ?>

<div class="content-header">
<div class="container-fluid">
<div class="row mb-2">
<div class="col-sm-6">
<!-- <h1 class="m-0">Leaves</h1> -->
</div>
<div class="col-sm-6">
<ol class="breadcrumb float-sm-right">
<!-- <li class="breadcrumb-item"><a href="#">Home</a></li>
<li class="breadcrumb-item active">Leaves</li> -->
</ol>
</div>
</div>
</div>
</div>

<?= $this->endSection() ?>

<?= $this->section('section-content') ?>

<section class="content">

<div class="container-fluid">

<div class="row">

<div class="col-sm-12">

<div class="card">

<div class="card-header">
    <?=    $this->include('admin/admin_attendance/tabs')    ?>
</div>

<div class="card-body">
<table class="table table-striped" id="leaves">
      <thead style="white-space: nowrap;">
        <tr>
          <th>ID</th>
          <th>Employee Code</th>
          <th>Name</th>
          <th>Status</th>
          <th>Date/Time</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody></tbody>
    </table>
  </div>
</div>
</div>
</div>
</div>
</section>
<?=  $this->endSection() ?>

<?=  $this->section('scripts')  ?>
<script>

$(document).ready(function(){

  
var url = "<?php echo base_url(); ?>";
var site_url = url+'/admin/';

var leave_table = $('#leaves').DataTable({
// lengthMenu: [[ 10, 30, -1], [ 10, 30, "All"]], // page length options
bProcessing: true,
serverSide: true,
scrollY: "400px",
scrollCollapse: true,
"language": {
      "emptyTable": "No Record Found"
    },
ajax: {
  url: site_url+"ajax-load-leaves", 
  type: "post",
  data: function (d) {
                    return $.extend({}, d, {
                      "date_pick" : $('#test').attr('data-block')
                    });
                }
},
columns: [
  { data: "id" },
  { data: "employee_code"},
  { data: "name" },
  { data: "status" },
  { data: "date" },
  { data: "action" }
],
columnDefs: [
  { orderable: false, targets: [0, 1, 2, 3] }
],
bFilter: true, // to display datatable search
});


$('#filter').click(function (e) {
      
     leave_table.ajax.reload();
 });

 $("#def_value").on("change", function () {
       var fromdate = $(this).val();
      $('#test').attr('data-block',fromdate);
   });



});


</script>
<?=  $this->endSection() ?>