<?= $this->extend('welcome_message') ?>

<?= $this->section('login-page') ?>
<!-- <div class="wrapper-page">
         <div class="card">
            <div class="card-body">
             <div class="p-3">
                  <h5 class="text-center">Daily Working Status</h5>
               </div>
               <div class="p-3">
             <form  class="form-horizontal&#x20;m-t-10" id="my-login-form" autocomplete="off" method="post" accept-charset="utf-8">
                     <div class="form-group">
                           <label for="username">Employee Code</label> 
                           <input type="text" class="form-control" name="emp_code" id="emp_code" placeholder="Enter employee code" >
                     </div>
                    
                        <div class="form-group">
                           <label for="userpassword">Password</label> 
                           <input type="password" class="form-control" name="Password" id="Password" placeholder="Enter password" >
                        </div>
                        <div class="form-group row m-t-30">
                           <div class="col-sm-6">
                        <button class="btn btn-block btn-info w-md waves-effect waves-light" type="button" id="check_in">Check In</button>
                     </div>
                     <div class="col-sm-6">
                     <button class="btn btn-block btn-info w-md waves-effect waves-light" type="button" id="leave_btn"> On Leave Today</button>
                     </div>
                        </div>
                        <div class="form-group m-t-30 mb-0 row">
                         
                        </div>
                  </form>              
              </div>

              <div id="message"></div>
              <div id="leave_message"></div>

            </div>
         </div>
      </div> -->

    <div class="container-fluid">
      <div class="container-fluid">
        <div class="main-container">
          <div class="right-main-container">
            <img
              class="right-image1"
              src="<?= base_url('public/frontend/images/illustration.png') ?>"
              alt=""
              srcset=""
            />
          </div>
          <div class="left-main-container">
            <div class="left-side-main-container">
              <img class="logo" src="<?=  base_url('public/frontend/images/Logo.png')  ?>" alt="logo" />
              <div class="input-box-container">
                <h5 class="heading">Daily Working Status</h5>

                <div class="input-section">
                  <form class="flex-c" id="my-login-form" autocomplete="off" method="post" accept-charset="utf-8">
                    <div class="input-box">
                      <span class="label">Employee Code</span>
                      <div class="flex-r input">
                        <input type="text"  name="emp_code" id="emp_code" placeholder="Enter employee code" >
                       <!--  <input type="text" placeholder="Enter your employee code" required /> -->
                        <i class="fas fa-at"></i>
                      </div>
                    </div>

                    <div class="input-box">
                      <span class="label">Password</span>
                      <div class="flex-r input">
                          <input type="password" name="Password"  placeholder="Enter Password" id="id_password">
                       <!--  <input type="password" placeholder= "Enter Password"  autocomplete="current-password" required="" id="id_password"/> -->
                        <i class="fa-solid fa-eye"></i>
                        <i  id="togglePassword"   style="cursor: pointer; color: grey" class="fas fa-eye"></i>
                      </div>
                    </div>

                    <div class="button-section">
                      <button type="button" class="btn btn-primary button11 " id="check_in">
                        Check In
                      </button>
                      <button type="button" class="btn btn-secondary button12" id="leave_btn">
                        On Leave Today
                      </button>
                    </div>
                  </form>
                </div>
              </div>
            </div>
          </div>
           <div id="message"></div>
           <div id="leave_message"></div>
        </div>
      </div>
    </div>





<?=  $this->endSection() ?>

<?= $this->section('scripts') ?>
<script>

$(document).ready(function () {

$('#my-login-form').validate({ // initialize the plugin
    rules: {
        emp_code: {
            required: true,
        },
        Password: {
            required: true,
        }
    },
    messages :{
        emp_code:{
            required : 'The Employee Code field is required.'
        },
        Password:{
            required : 'The Password Field is required.'
        }
    }
});

$('#check_in').on('click',function(){

     //This will check validation of form depending on rules
     if($("#my-login-form").valid())
    {
        var form_data = $("#my-login-form").serialize();
        var url = "<?php echo base_url(); ?>";
        var site_url = url+'/';

        $.ajax({  
        url: site_url+"check-in",
        type: 'post',
        dataType:'json',
        data:form_data,
        success:function(data){
            if(data.status == true)
            {
                 $('#message').html('<table class="table table-borderless" style="line-height:2%;padding:5px 3px 3px 3px" border="1" cellpadding="0" cellspacing="0" width="95%"><tbody><tr height="25"><td align="LEFT" valign="top" style="font-size:17px; color:blue"><b><br>&nbsp; Dear,'+data.data.name+' <br><br></b></td></tr><tr height="25"> <td align="LEFT" valign="top" style="font-size:11px; color:blue"><b><br>&nbsp; '+data.message+' <br><br></b></td></tr></tbody></tbody></table>');
                 $('#Password').val('');
            }
            else
            {
               $('#message').html('<table style="line-height:130%;padding:5px 3px 3px 3px" border="1" cellpadding="0" cellspacing="0" width="95%"><tbody><tr height="25"><td align="CENTER" valign="top" style="font-size:17px; color:red"><b><br>&nbsp; '+data.message+' <br><br></b></td></tr></tbody></table>').fadeIn(3000).fadeOut(3000);
               $('#Password').val('');
            }
        }  
        });

    }

});

$('#leave_btn').on('click',function(){
    if($("#my-login-form").valid())
    {
        var form_data = $("#my-login-form").serialize();
        var url = "<?php echo base_url(); ?>";
        var site_url = url+'/';

        $.ajax({  
        url: site_url+"leaves",
        type: 'post',
        dataType:'json',
        data:form_data,
        success:function(data){
            if(data.status == true)
            {
                 $('#leave_message').html('<table class="table table-borderless" style="line-height:2%;padding:5px 3px 3px 3px" border="1" cellpadding="0" cellspacing="0" width="95%"><tbody><tr height="25"><td align="LEFT" valign="top" style="font-size:17px; color:blue"><b><br>&nbsp; Dear,'+data.data.name+' <br><br></b></td></tr><tr height="25"> <td align="LEFT" valign="top" style="font-size:11px; color:blue"><b><br>&nbsp; '+data.message+' <br><br></b></td></tr></tbody></tbody></table>').fadeIn(3000).fadeOut(3000);
                 $('#Password').val('');
            }
            else
            {
               $('#leave_message').html('<table style="line-height:130%;padding:5px 3px 3px 3px" border="1" cellpadding="0" cellspacing="0" width="95%"><tbody><tr height="25"><td align="CENTER" valign="top" style="font-size:17px; color:red"><b><br>&nbsp; '+data.message+' <br><br></b></td></tr></tbody></table>').fadeIn(3000).fadeOut(3000);
               $('#Password').val('');
            }
        }  
        });
            
    }
});


});


</script>
<?=  $this->endSection() ?>



